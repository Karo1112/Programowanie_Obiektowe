package agh.ics.oop;

public class IMapElement {
    //ten interejs mógłby zwracać pozycję obiektu.
}
